import { defineConfig } from "vitest/config";
export default defineConfig({ test: { include: ["test/lifecycle-audit/*.test.ts"] } });
