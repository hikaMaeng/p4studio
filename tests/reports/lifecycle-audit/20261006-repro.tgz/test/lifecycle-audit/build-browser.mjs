// Reuse the already-established binary P4/HTTP fixture and locators.
import fs from "node:fs/promises";
const source = await fs.readFile("test/20261006/004800_stop-ui/browser-check.mjs", "utf8");
let harness = source.slice(0, source.indexOf('try {\n  await scenario("history-list-stop"'));
harness = harness.replace('const page = await context.newPage(), errors = [], sent = [], requests = new Map()', 'const page = await context.newPage(), errors = [], sent = [], httpRequests = [], requests = new Map()');
harness = harness.replace('const pathname = new URL(route.request().url()).pathname;', 'httpRequests.push({ url: route.request().url(), method: route.request().method() }); const pathname = new URL(route.request().url()).pathname;');
harness = harness.replace('await work({ page, capture, count, run });', 'await work({ page, capture, count, run, httpRequests });');
harness = harness.replace('results.push({ name, status: "passed", sent });', 'results.push({ name, status: "passed", sent, httpRequests });');
harness = harness.replace('requests.set(body.request_id, { event, body, sequence });', `requests.set(body.request_id, { event, body, sequence });
          if (mode === "request-error" && sequence === 1) setTimeout(() => send(response(event, "application/vnd.p4.llamacpp.error-v2+json", { code: "LLAMA_ADAPTER_EVENT_REJECTED", detail: "request storage budget exhausted", submission: { load_generation: 42, session_id: body.session_id, request_id: body.request_id, submission_event_id: event.eventId } })), 500);`);
harness += `try {
  await scenario("request-detail-no-stop", "streaming", async ({ page, capture, count }) => {
    await expect.poll(() => count("prefill-v3")).toBe(2);
    const row = page.getByTestId("inference-request-row").first();
    const details = page.getByRole("button", { name: "통계와 요청 상세 열기/닫기", exact: true });
    if (await details.getAttribute("aria-expanded") !== "true") await details.click();
    const wave = page.getByTestId("inference-wave-toggle").first();
    await expect(wave).toBeVisible();
    if (await wave.getAttribute("aria-expanded") !== "true") await wave.click();
    await row.click();
    await expect(page.getByTestId("inference-request-detail")).toBeVisible();
    await expect(page.getByTestId("inference-run-stop")).toHaveCount(0);
    await capture("missing-stop");
    // Return to the query via real browser history: the same live run still has a stop button.
    await page.goBack(); await expect(page.getByTestId("inference-run-stop")).toBeVisible();
    await capture("query-stop-visible");
  });
  await scenario("error-no-stop", "request-error", async ({ page, capture, count, run }) => {
    await expect.poll(() => count("prefill-v3")).toBe(2);
    await expect(page.getByTestId("inference-run-group").getByText("실패", { exact: true }).first()).toBeVisible();
    await expect(page.getByTestId("inference-run-stop")).toHaveCount(0);
    assert.equal(count("cancel-v1"), 0);
    const saved = await run(); assert.equal(saved.state, "failed"); assert(saved.requests.every(request => request.state === "failed"));
    await capture("missing-recovery-control");
  });
  await scenario("model-owner-discard", "streaming", async ({ page, capture, count, httpRequests }) => {
    await expect.poll(() => count("prefill-v3")).toBe(2);
    await page.getByRole("button", { name: "모델", exact: true }).click();
    await page.getByTestId("model-row").getByRole("button", { name: "모델 기록 삭제", exact: true }).click();
    await expect.poll(() => httpRequests.filter(request => request.method === "DELETE").length).toBe(1);
    assert(httpRequests.some(request => request.method === "DELETE" && request.url.endsWith("?discard=true")));
    assert.equal(count("cancel-v1"), 0); assert.equal(count("node.unload"), 0);
    await expect(page.getByRole("dialog")).toHaveCount(0);
    await capture("discard-without-unload-or-confirmation");
  });
} catch (error) { status = "failed"; failure = error.stack; }
await fs.writeFile(path.join(out, "browser-report.json"), JSON.stringify({ status, url, evidence: "Defect reproduction, NOT functionality acceptance. Deployed UI; real Chromium; P4 binary and HTTP fixtures. No GPU execution.", results, screenshots, failure }, null, 2));
await browser.close();
console.log(JSON.stringify({ status, scenarios: results.length, report: path.join(out, "browser-report.json"), failure }));
if (status !== "passed") process.exitCode = 1;
`;
await fs.mkdir("test/20261006/145100_lifecycle-defects", { recursive: true });
await fs.writeFile("test/20261006/145100_lifecycle-defects/browser-check.mjs", harness);
