# Headless Browser Test

- status: passed
- mode: smoke
- inputUrl: http://127.0.0.1:43120
- testedUrl: http://127.0.0.1:43120/
- finalUrl: http://127.0.0.1:43120/
- documentStatus: 200
- title: P4 Studio
- mainPresent: true
- consoleErrors: 0
- pageErrors: 0
- trace: F:\dev\p4studio\test\20261006\150511_headless-browser-test\trace.zip
- screenshots: 1

## Screenshots
- F:\dev\p4studio\test\20261006\150511_headless-browser-test\screenshots\smoke.png

## Step Results
- 1. goto: passed
- 2. assertRole: passed
- 3. screenshot: passed

## Browser Errors
